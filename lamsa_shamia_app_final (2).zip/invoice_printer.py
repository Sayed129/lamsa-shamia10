# Invoice printing logic
