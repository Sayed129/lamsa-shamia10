# Main logic of the app with all systems
